# 🚗 WrapStudio — Deploy in 5 Minutes (No Build Required)

This is a **zero-build** static app. One HTML file. Works instantly on Vercel.

---

## Files
```
wrapstudio/
├── index.html          ← The entire app (React via CDN)
├── vercel.json         ← Vercel config
├── public/
│   ├── icon-192.png
│   ├── icon-512.png
│   ├── apple-touch-icon.png
│   └── favicon.ico
```

---

## Deploy to Vercel (2 Steps)

### Step 1 — Push to GitHub
1. Go to **github.com** → New repository → name it `wrapstudio`
2. On your computer, open Terminal and run:
```bash
cd path/to/wrapstudio
git init
git add .
git commit -m "WrapStudio app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/wrapstudio.git
git push -u origin main
```

### Step 2 — Deploy on Vercel
1. Go to **vercel.com** → Add New Project
2. Import `wrapstudio` from GitHub
3. **Important**: Under "Build & Output Settings":
   - Build Command: leave **empty** (delete any default)
   - Output Directory: leave **empty** (delete any default)  
   - Framework Preset: **Other**
4. Click **Deploy**
5. Done! Your live URL appears in ~10 seconds ✅

---

## Install on iPhone
1. Open your Vercel URL in **Safari**
2. Tap **Share** (□↑) → **Add to Home Screen**
3. Tap **Add** ✅

## Install on Android
1. Open your Vercel URL in **Chrome**
2. Tap **⋮** menu → **Install app**
3. Tap **Install** ✅

---

## Update the App
Edit `index.html`, then:
```bash
git add . && git commit -m "update" && git push
```
Vercel redeploys in ~10 seconds automatically.
